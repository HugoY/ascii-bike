#ifndef BIKE_H
#define BIKE_H

#include "Road.h"

class Bike
{
public:
    Bike();
    void run(const Road & road);
};

#endif // BIKE_H
